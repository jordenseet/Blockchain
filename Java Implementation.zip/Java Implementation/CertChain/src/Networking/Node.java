package Networking;


import certchain.Blockchain;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;

public class Node {

    private Thread peerThread;
    public static Socket socket;
    Blockchain toSend;
    Blockchain storage;
    public static ObjectOutputStream out;
    public ObjectInputStream in;
    //ArrayList<ObjectOutputStream>  outStreams;

    public Node(Socket socket, ObjectOutputStream out, ObjectInputStream in) {
        this.socket = socket;
        this.out = out;
        this.in = in;
        //this.outStreams = new ArrayList<ObjectOutputStream>();
        peerThread = new Thread(new Runnable() {
            public void run() {
                receive(in);
            }
        });
        peerThread.start();
    }

    public static boolean send(Blockchain blockchain, ObjectOutputStream out) {
        System.out.println("Sending Blockchain" + blockchain);
        try {
            System.out.println(out);
            out.writeObject(blockchain);
            out.flush();
            System.out.println("Flushed successfully!");
            System.out.println("Succeeded sending Blockchain!");
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean receive(ObjectInputStream in) {
        try {
            Blockchain blockchain =(Blockchain)in.readObject();
            System.out.println("Downloaded Blockchain Successfully!");
            storage = blockchain;
            return true;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public Blockchain getBlockchain(){
        return storage;
    }
}
