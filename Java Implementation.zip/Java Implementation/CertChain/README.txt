This is my attempt at a Java-based implementation of a blockchain.
The scenario is an "Certchain", which is a permissioned blockchain between accredited universities and companies to obtain tamper-proof, accredited student certifications.

First Phase: Getting the Blockchain logic
Second Phase: Setting up p2p networking 
Third Phase: Work on a better Consensus protocol
Fourth Phase: Front-end

Currently still working on second phase, if you have any advice just hit me up! 

Thanks for viewing my project.